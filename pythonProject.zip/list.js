document.addEventListener('DOMContentLoaded', function() {
    fetchReservations();
});

function fetchReservations() {
    fetch('http://127.0.0.1:5000/reservations', { method: 'GET' })
    .then(response => response.json())
    .then(data => {
        const container = document.getElementById('reservationsList');
        container.innerHTML = ''; // Clear previous contents
        data.forEach(reservation => {
            const reservationDiv = document.createElement('div');
            reservationDiv.className = 'reservation';
            reservationDiv.innerHTML = `
                <h3>${reservation.name}</h3>
                <p>Date: ${new Date(reservation.date).toLocaleDateString()}</p>
                <p>Time: ${reservation.time}</p>
                <p>Guests: ${reservation.number_of_guests}</p>
            `;
            container.appendChild(reservationDiv);
        });
    })
    .catch(error => {
        console.error('Error fetching reservations:', error);
        alert('Could not load reservations.');
    });
}
