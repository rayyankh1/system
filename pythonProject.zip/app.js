document.getElementById('reservationForm').addEventListener('submit', function(event) {
    event.preventDefault();  // Prevent the form from submitting the default way

    var formData = {
        name: document.getElementById('name').value,
        date: document.getElementById('date').value,
        time: document.getElementById('time').value,
        number_of_guests: parseInt(document.getElementById('guests').value, 10)
    };

    fetch('http://127.0.0.1:5000/reservations', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        window.location.href = 'thankyou.html';  // Redirect to thank you page
    })
    .catch((error) => {
        console.error('Error:', error);
        alert('Error making reservation');
    });
});
