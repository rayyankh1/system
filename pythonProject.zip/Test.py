import requests

# To create a reservation
response = requests.post(
    'http://127.0.0.1:5000/reservations',
    json={
        "name": "Rayyan Kherati",
        "date": "2023-10-01",
        "time": "18:00",
        "number_of_guests": 3
    }
)
print(response.json())

# To get all reservations
response = requests.get('http://127.0.0.1:5000/reservations')
print("Response object: ", response.json())