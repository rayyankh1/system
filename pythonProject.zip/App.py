from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from flask_cors import CORS

app = Flask(__name__)
CORS(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///reservations.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Reservation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    date = db.Column(db.DateTime, nullable=False)
    time = db.Column(db.String(5), nullable=False)
    number_of_guests = db.Column(db.Integer, nullable=False)

    def to_json(self):
        return {
            "id": self.id,
            "name": self.name,
            "date": self.date.isoformat(),
            "time": self.time,
            "number_of_guests": self.number_of_guests
        }

first_request = True

@app.before_request
def create_tables():
    global first_request
    if first_request:
        db.create_all()
        first_request = False

@app.route('/reservations', methods=['GET'])
def get_reservations():
    reservations_non_converted = Reservation.query.all()

    reservations_list_converted = []

    for reservation_non_converted in reservations_non_converted:
        reservation_in_json = reservation_non_converted.to_json()
        #add to converted list
        reservations_list_converted.append(reservation_in_json)

    return jsonify(reservations_list_converted), 200

@app.route('/reservations', methods=['POST'])
def create_reservation():
    content = request.json
    reservation = Reservation(
        name=content['name'],
        date=datetime.strptime(content['date'], '%Y-%m-%d'),
        time=content['time'],
        number_of_guests=content['number_of_guests']
    )
    db.session.add(reservation)
    db.session.commit()
    return jsonify(reservation.to_json()), 201

if __name__ == '__main__':
    app.run(debug=True)